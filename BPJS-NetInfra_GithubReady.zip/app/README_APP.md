
# App Notes

This is a minimal Jetpack Compose skeleton. To convert into a runnable project:
- Create a new Android Studio project (Empty Compose Activity).
- Copy the files from `app/src/main/...` into the new project's `app/src/main/...`.
- Add dependencies for Material3 and Jetpack Compose in build.gradle (app level).
